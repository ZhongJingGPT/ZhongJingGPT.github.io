import sys
import torch
from peft import PeftModel, PeftModelForCausalLM, LoraConfig
import transformers
import gradio as gr
import argparse
import warnings
import os
import json
import torch
import streamlit as st
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers.generation.utils import GenerationConfig
from peft import AutoPeftModelForCausalLM

def init_model():
    tokenizer = AutoTokenizer.from_pretrained("/home/ubuntu/bc2/Baichuan2-git-main/fine-tune/output", 
                                              use_fast=False, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained("/home/ubuntu/bc2/Baichuan2-git-main/fine-tune/output", 
                                                     device_map="auto", torch_dtype=torch.bfloat16, trust_remote_code=True)
    
    model.generation_config = GenerationConfig.from_pretrained(
        "/home/ubuntu/bc2/Baichuan2-git-main/fine-tune/output"
    )
    return model, tokenizer

model, tokenizer = init_model()

def evaluate(
    input,
    temperature=0.1,
    top_p=0.75,
    top_k=40,
    num_beams=4,
    max_new_tokens=128,
    min_new_tokens=1,
    repetition_penalty=2.0,
    **kwargs,
):
    messages = []
    messages.append({"role": "user", "content": input})
    response = model.chat(tokenizer, messages)
    yield response


gr.Interface(
    fn=evaluate,
    inputs=[
        gr.components.Textbox(
            lines=2, label="Input", placeholder="Tell me."
        ),
        #gr.components.Slider(minimum=0, maximum=1, value=0.1, label="Temperature"),
        #gr.components.Slider(minimum=0, maximum=1, value=0.75, label="Top p"),
        #gr.components.Slider(minimum=0, maximum=100, step=1, value=40, label="Top k"),
        #gr.components.Slider(minimum=1, maximum=10, step=1, value=5, label="Beams Number"),
        #gr.components.Slider(
        #    minimum=1, maximum=2000, step=1, value=512, label="Max New Tokens"
        #),
        #gr.components.Slider(
        #    minimum=1, maximum=300, step=1, value=128, label="Min New Tokens"
        #),
        #gr.components.Slider(
        #    minimum=0.1, maximum=10.0, step=0.1, value=3.8, label="Repetition Penalty"
        #),
    ],
    outputs=[
        gr.components.Textbox(
            lines=25,
            label="Output",
        )
    ],
    title="ZhongJing-TCM-BaiChuan2-13B",
    description="ZhongJing-TCM-BaiChuan2-13B",
).queue().launch(share=True)