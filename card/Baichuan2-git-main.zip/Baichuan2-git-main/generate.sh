TOT_CUDA="0,1,2,3,4,5,6,7,8"
CUDAs=(${TOT_CUDA//,/ })
CUDA_NUM=${#CUDAs[@]}

CUDA_VISIBLE_DEVICES=${TOT_CUDA} python3 generate.py \